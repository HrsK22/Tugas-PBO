import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
from FrmLogin import *
from FrmOrderMakanan import *
from FrmRiwayatPemesanan import *

class Dashboard:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title('Menu Dashboard')
        self.__data = None
        self.__level = None
        self.root.resizable(False, False)
        self.center_window()
        self.set_icon()

        # Buttons for customer
        self.customer_button1 = tk.Button(self.root, text='Pesan', command=lambda: self.new_window("Pesan", PesanMakanan))
        self.customer_button2 = tk.Button(self.root, text='Riwayat Pemesanan', command=lambda: self.new_window("Riwayat Pemesanan", RiwayatPemesanan))


        # Buttons for Mahasiswa
        self.admin_button1 = tk.Button(self.root, text='Mahasiswa-1', command=lambda: self.new_window("Luas Persegi", ))
        self.admin_button2 = tk.Button(self.root, text='Mahasiswa-2', command=lambda: self.new_window("Luas Segitiga", ))

        self.buttons = {
            'customer': [self.customer_button1, self.customer_button2],
            'admin': [self.admin_button1, self.admin_button2],
        }

        self.label = tk.Label(self.root, text='Selamat Datang')
        self.label.grid(row=0, column=0, columnspan=5, sticky='NSEW', padx=5, pady=5)
        self.login_button = tk.Button(self.root, text='Login', command=lambda: self.new_window("Log Me In", FormLogin))
        self.login_button.grid(row=1, sticky='NSEW', columnspan=2, padx=5, pady=5)
        self.login_button.config(width=25, height=2)
        self.logout_button = tk.Button(self.root, text='Logout', command=self.Logout)

        # Create a dictionary to map the level to the corresponding buttons
        self.button_dict = {
            'customer': self.customer_button1,
            'mahasiswa': self.admin_button1,
        }

        self.run()

    def set_icon(self):
        # Baca file PNG menggunakan PIL
        icon_image = Image.open("icon.png")

        # Ubah gambar menjadi format yang dapat digunakan oleh Tkinter
        tk_icon = ImageTk.PhotoImage(icon_image)

        # Set ikon untuk jendela
        self.root.iconphoto(False, tk_icon)

    def center_window(self):
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        # Calculate the position to center the window
        x = (screen_width - 200) // 2
        y = (screen_height - 250) // 2

        # Set the window geometry with initial position
        self.root.geometry("200x250+{}+{}".format(x, y))

    def new_window(self, number, _class):
        new = tk.Toplevel(self.root)
        new.transient()
        new.grab_set()

        if _class == FormLogin:
            _class(new, number, self.update_main_window)
        elif _class == PesanMakanan:
            _class(new, self.root)
        elif _class == RiwayatPemesanan:
            _class(new, self.update_main_window)

    def update_main_window(self, data):
        self.__data = data
        level = self.__data[0]
        login_valid = self.__data[1]

        if login_valid:
            self.login_button.grid_forget()
            self.logout_button.grid(row=3, column=0, sticky='NSEW',padx=5, pady=5)
            self.logout_button.config(width=25, height=2)

            for button_list in self.buttons.values():
                for button in button_list:
                    button.grid_forget()

            if level == 'customer':
                self.customer_button1.grid(row=1, column=0, sticky='NSEW',padx=5, pady=5)
                self.customer_button1.config(width=25, height=2)
                self.customer_button2.grid(row=2, column=0, sticky='NSEW',padx=5, pady=5)
                self.customer_button2.config(width=25, height=2)

            elif level == 'admin':
                self.admin_button1.grid(row=1, column=0, padx=5, pady=5)
                self.admin_button2.grid(row=2, column=0, padx=5, pady=5)

    def Logout(self):
        # Hide the logout button and display the login button
        self.logout_button.grid_forget()
        self.login_button.grid(row=1, column=0, padx=5, pady=5)

        # Hide all buttons
        for button_list in self.buttons.values():
            for button in button_list:
                button.grid_forget()

        # Reset the current user level
        self.__level = None

    def run(self):
        self.root.configure(bg="red")
        self.label = tk.Label(self.root, text='Selamat Datang\nDiBebek Carok')
        self.label.grid(row=0, column=0, columnspan=5, sticky='NSEW', padx=5, pady=5)
        self.label.config(fg="white", bg="grey", width=15, height=2, bd=5,relief='solid',font=('Helvetica', 15, 'bold'))
        self.login_button.grid(row=1, column=0, padx=5, pady=5)
        try:
            while True:
                self.root.update()
                self.root.update_idletasks()
        except tk.TclError:
            pass

if __name__ == "__main__":
    menu_app = Dashboard()
    menu_app.run()