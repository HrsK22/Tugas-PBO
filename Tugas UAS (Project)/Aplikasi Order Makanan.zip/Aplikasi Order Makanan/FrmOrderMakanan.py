import tkinter as tk
from tkinter import Frame,Label,Entry,Button,ttk,VERTICAL,YES,BOTH,END,Tk,W,N,NE,E,StringVar,messagebox, Text, Scrollbar
from PIL import Image, ImageTk
from tabeldb_makanan import menu_makanan
from tabeldb_minuman import menu_minuman
from tabeldb_riwayatPesanan import riwayat_pesanan

class PesanMakanan:
    def __init__(self, parent, window_before):
        self.parent = parent
        self.window_before = window_before
        self.parent.title("Pesan Makanan")
        self.menu_makanan_combobox = None
        self.parent.resizable(False, False)
        self.txtharga_total = Label(parent, text='Total Harga: 0 Rp')
        self.center_window()
        self.aturKomponen()
        self.set_icon()

    def set_icon(self):
        icon_image = Image.open("icon.png")
        tk_icon = ImageTk.PhotoImage(icon_image)
        self.parent.iconphoto(False, tk_icon)

    def center_window(self):
        screen_width = self.parent.winfo_screenwidth()
        screen_height = self.parent.winfo_screenheight()

        x = (screen_width - 705) // 2
        y = (screen_height - 520) // 2

        self.parent.geometry("705x520+{}+{}".format(x, y))

    def aturKomponen(self):
        mainFrame = Frame(self.parent, bd=10, bg='red')
        mainFrame.pack(fill=BOTH, expand=YES)

        Label(mainFrame, text='Menu Order', fg="white", bg="grey", width=15, height=2, bd=5,relief='solid',font=('Helvetica', 15, 'bold')).grid(row=0, column=0, columnspan=5 ,sticky='NSEW', padx=5, pady=5)

        Label(mainFrame, text='Pilih Makanan:', bg='grey', bd=2, relief='solid', font=('Helvetica')).grid(row=1, column=0, sticky=W, padx=5, pady=5)
        self.menu_makanan_var = StringVar()
        self.menu_makanan_combobox = ttk.Combobox(mainFrame, textvariable=self.menu_makanan_var, width=30, state='readonly')
        self.menu_makanan_combobox.grid(row=1, column=1, padx=5, pady=5)
        menu_data = menu_makanan().getAllData()
        menu_names = [menu[2] for menu in menu_data]  
        self.menu_makanan_combobox['values'] = menu_names
        self.menu_makanan_combobox.bind("<<ComboboxSelected>>", self.update_harga_makanan)
        self.txtharga_makanan = Label(mainFrame, text='Rp: xxxxx', bg='grey', bd=2, relief='solid')
        self.txtharga_makanan.grid(row=1, column=2, padx=5, pady=5)
        self.jumlah_makanan_var = StringVar()
        self.jumlah_makanan_entry = Entry(mainFrame, width=5, textvariable=self.jumlah_makanan_var)
        self.jumlah_makanan_entry.grid(row=1, column=3, padx=5, pady=5)
        btnTambah_makanan = Button(mainFrame, text='Tambah Makanan', command=self.btnTambah_makanan_click, width=15, height=1)
        btnTambah_makanan.grid(row=1, column=4)

        Label(mainFrame, text='Pilih Minuman:', bg='grey', bd=2, relief='solid', font=('Helvetica')).grid(row=2, column=0, sticky=W, padx=5, pady=5)
        self.menu_minuman_var = StringVar()
        self.menu_minuman_combobox = ttk.Combobox(mainFrame, textvariable=self.menu_minuman_var, width=30, state='readonly')
        self.menu_minuman_combobox.grid(row=2, column=1, padx=5, pady=5)
        menu_data = menu_minuman().getAllData()
        menu_names = [menu[2] for menu in menu_data]  
        self.menu_minuman_combobox['values'] = menu_names
        self.menu_minuman_combobox.bind("<<ComboboxSelected>>", self.update_harga_minuman)
        self.txtharga_minuman = Label(mainFrame, text='Rp: xxxxx', bg='grey', bd=2, relief='solid')
        self.txtharga_minuman.grid(row=2, column=2 ,padx=5, pady=5)
        self.jumlah_minuman_var = StringVar()
        self.jumlah_minuman_entry = Entry(mainFrame, width=5, textvariable=self.jumlah_minuman_var)
        self.jumlah_minuman_entry.grid(row=2, column=3, padx=5, pady=5)
        btnTambah_minuman = Button(mainFrame, text='Tambah Minuman', command=self.btnTambah_minuman_click, width=15, height=1)
        btnTambah_minuman.grid(row=2, column=4)

        Label(mainFrame, text='Ongkir: Rp 15.000', bg='grey', bd=2, relief='solid').grid(row=3, column=0, sticky=W, padx=5, pady=5)

        self.tree = ttk.Treeview(mainFrame, columns=('Menu', 'Jumlah', 'Harga'), show='headings')
        self.tree.heading('Menu', text='Menu')
        self.tree.column('Menu', width="200")
        self.tree.heading('Jumlah', text='Jumlah')
        self.tree.column('Jumlah', width="50")
        self.tree.heading('Harga', text='Harga')
        self.tree.column('Harga', width="75")
        self.tree.grid(row=4, rowspan=3, columnspan=2, pady=20)

        Button(mainFrame, text='Kembali', width=15, height=2, command=self.btnKembali_click).grid(row=7, column=0)

        Button(mainFrame, text="Hapus Menu yang Dipilih", command=self.btnHapus_menu_click, width=20, height=2).grid(row=4, column=3)
        Button(mainFrame, text='Cek Harga', command=self.btnCekHarga_click, width=20, height=2).grid(row=5, column=3)
        Button(mainFrame, text="Bayar", command=self.btnBayar_click, width=20, height=2).grid(row=6, column=3)

    def update_harga_makanan(self, event):
        selected_index = self.menu_makanan_combobox.current()
        if selected_index >= 0:
            menu_data = menu_makanan().getAllData()
            
            harga_menu = menu_data[selected_index][3]

            self.txtharga_makanan.config(text=f'Rp:{harga_menu}')

    def update_harga_minuman(self, event):
        selected_index = self.menu_minuman_combobox.current()
        if selected_index >= 0:
            menu_data = menu_minuman().getAllData()
            
            harga_menu = menu_data[selected_index][3]

            self.txtharga_minuman.config(text=f'Rp:{harga_menu}')

    def btnHapus_menu_click(self):
        selected_item = self.tree.selection()

        for item in selected_item:
            self.tree.delete(item)

        self.update_total_harga()

    def btnTambah_makanan_click(self):
        menu_index = self.menu_makanan_combobox.current()
        jumlah_str = self.jumlah_makanan_var.get()

        if menu_index >= 0:
            try:
                jumlah = int(jumlah_str)
                if jumlah > 0:
                    menu_data = menu_makanan().getAllData()
                    harga_menu = menu_data[menu_index][3]
                    total_harga = harga_menu * jumlah

                    self.tree.insert('', 'end', values=(self.menu_makanan_var.get(), jumlah, total_harga))

                    self.menu_makanan_combobox.set('')
                    self.jumlah_makanan_var.set('')
                    self.update_total_harga()
                else:
                    messagebox.showinfo("Info", "Jumlah pesanan harus lebih dari 0.")
            except ValueError:
                messagebox.showinfo("Info", "Inputan harus berupa angka.")
        else:
            messagebox.showinfo("Info", "Pilih pesanan terlebih dahulu.")

    def btnTambah_minuman_click(self):
        menu_index = self.menu_minuman_combobox.current()
        jumlah_str = self.jumlah_minuman_var.get()

        if menu_index >= 0:
            try:
                jumlah = int(jumlah_str)
                if jumlah > 0:
                    menu_data = menu_minuman().getAllData()
                    harga_menu = menu_data[menu_index][3]
                    total_harga = harga_menu * jumlah

                    self.tree.insert('', 'end', values=(self.menu_minuman_var.get(), jumlah, total_harga))

                    self.menu_minuman_combobox.set('')
                    self.jumlah_minuman_var.set('')
                    self.update_total_harga()
                else:
                    messagebox.showinfo("Info", "Jumlah pesanan harus lebih dari 0.")
            except ValueError:
                messagebox.showinfo("Info", "Inputan harus berupa angka.")
        else:
            messagebox.showinfo("Info", "Pilih pesanan terlebih dahulu.")

    def update_total_harga(self):
        total_harga = 0
        for child in self.tree.get_children():
            total_harga += float(self.tree.item(child, 'values')[2])
        self.txtharga_total.config(text=f'Total Harga: {total_harga} Rp')

    def btnBayar_click(self):
        if not self.tree.get_children():
            messagebox.showinfo("Info", "Masukkan item terlebih dahulu.")
            return

        selected_orders = self.get_selected_orders()

        self.clear_treeview()
        self.parent.withdraw()
        konfirmasi_pembayaran_window = tk.Toplevel(self.parent)
        KonfirmasiPembayaran(konfirmasi_pembayaran_window, selected_orders, self.parent)


    def clear_treeview(self):
        for item in self.tree.get_children():
            self.tree.delete(item)

        self.txtharga_total.config(text='Total Harga: 0 Rp')

    def get_selected_orders(self):
        selected_orders = []
        for child in self.tree.get_children():
            values = self.tree.item(child, 'values')
            if values:
                selected_orders.append((values[0], values[1], values[2]))
        return selected_orders

    def btnCekHarga_click(self):
        if not self.tree.get_children():
            messagebox.showinfo("Info", "Masukkan item terlebih dahulu.")
            return

        total_harga = self.calculate_total_price()

        ongkir = 15.000 
        total_harga += ongkir

        messagebox.showinfo("Total Harga", f"Total Harga (including ongkos kirim): Rp{total_harga:.3f}")

    def calculate_total_price(self):
        total_harga = 0
        for child in self.tree.get_children():
            values = self.tree.item(child, 'values')
            if values:
                total_harga += float(values[2])
        return total_harga

    def btnKembali_click(self):
        self.parent.destroy()

class KonfirmasiPembayaran:
    def __init__(self, parent, selected_orders, previous_window):
        self.parent = parent
        self.parent.title("Pembayaran")
        self.selected_orders = selected_orders
        self.previous_window = previous_window
        self.parent.resizable(False, False)
        self.aturKomponen()
        self.center_window()
        self.set_icon()

    def set_icon(self):
        icon_image = Image.open("icon.png")
        tk_icon = ImageTk.PhotoImage(icon_image)
        self.parent.iconphoto(False, tk_icon)

    def center_window(self):
        screen_width = self.parent.winfo_screenwidth()
        screen_height = self.parent.winfo_screenheight()

        x = (screen_width - 375) // 2
        y = (screen_height - 660) // 2

        self.parent.geometry("375x660+{}+{}".format(x, y))

    def aturKomponen(self):
        mainFrame = Frame(self.parent, bd=10, bg='red')
        mainFrame.pack(fill=BOTH, expand=YES)

        Label(mainFrame, text='Konfirmasi Pembayaran', fg="white", bg="grey", width=15, height=2, bd=5,relief='solid',font=('Helvetica', 15, 'bold')).grid(row=0, column=0, columnspan=5 ,sticky='NSEW', padx=5, pady=5)

        Label(mainFrame, text='Nama:', bg='grey', bd=2, relief='solid', font=('Helvetica')).grid(row=1, column=0, sticky=W, padx=5, pady=5)
        self.txtnama = Entry(mainFrame)
        self.txtnama.grid(row=1, column=1, padx=5, pady=5)

        Label(mainFrame, text='Nomor telepon:', bg='grey', bd=2, relief='solid', font=('Helvetica')).grid(row=2, column=0, sticky=W, padx=5, pady=5)
        self.txtnotelepon = Entry(mainFrame)
        self.txtnotelepon.grid(row=2, column=1, padx=5, pady=5)

        Label(mainFrame, text='Alamat:', bg='grey', bd=2, relief='solid', font=('Helvetica')).grid(row=3, column=0, sticky=W, padx=5, pady=5)
        self.txtalamat = Entry(mainFrame)
        self.txtalamat.grid(row=3, column=1, padx=5, pady=5)

        #Button
        Button(mainFrame, text="Konfirmasi Pembayaran",command=self.konfirmasi_pembayaran).grid(row=10, column=1)

        Button(mainFrame, text='Kembali', command=self.kembali_ke_sebelumnya, width=20, height=2).grid(row=11, column=0)

        Button(mainFrame, text='Simpan', command=self.simpan_data).grid(row=4, column=0)

        Button(mainFrame, text='Edit', command=self.edit_data_and_update_text).grid(row=4, column=1)
        self.display_text = Text(mainFrame, wrap="word", height=5, width=30, state='disabled')
        self.display_text.grid(row=5, column=0, columnspan=2, padx=5, pady=5)
   
        # Scrollbar for the Text widget
        scrollbar = Scrollbar(mainFrame, command=self.display_text.yview)
        scrollbar.grid(row=5, column=2, sticky='nsew')
        self.display_text.config(yscrollcommand=scrollbar.set)

        # Tabel pemesanan
        self.tree = ttk.Treeview(mainFrame, columns=('Menu', 'Jumlah', 'Harga'), show='headings')
        self.tree.heading('Menu', text='Menu')
        self.tree.column('Menu', width="200")
        self.tree.heading('Jumlah', text='Jumlah')
        self.tree.column('Jumlah', width="50")
        self.tree.heading('Harga', text='Harga')
        self.tree.column('Harga', width="75")
        self.tree.grid(row=6, rowspan=3, columnspan=2, pady=20) 
        for order in self.selected_orders:
            self.tree.insert('', 'end', values=order)

    def simpan_data(self):
        nama = self.txtnama.get()
        telepon = self.txtnotelepon.get()
        alamat = self.txtalamat.get()

        if not nama or not telepon or not alamat:
            messagebox.showinfo("Peringatan", "Mohon isi nama, nomor telepon, alamat terlebih dahulu.")
            return

        info_to_display = f"Nama: {nama}\nNomor Telepon: {telepon}\nAlamat: {alamat}\n"
        self.display_text.config(state='normal')
        self.display_text.delete(1.0, "end")
        self.display_text.insert("end", info_to_display)
        self.display_text.config(state='disabled')

    def edit_data_and_update_text(self):
        current_nama = self.txtnama.get()
        current_telepon = self.txtnotelepon.get()
        current_alamat = self.txtalamat.get()

        if not current_nama or not current_telepon or not current_alamat:
            messagebox.showinfo("Peringatan", "Inputkan terlebih dahulu sebelum melakukan edit.")
            return

        self.txtnama.config(state='normal')
        self.txtnotelepon.config(state='normal')
        self.txtalamat.config(state='normal')

        self.txtnama.focus()

        nama = self.txtnama.get()
        telepon = self.txtnotelepon.get()
        alamat = self.txtalamat.get()

        info_to_display = f"Nama: {nama}\nNomor Telepon: {telepon}\nAlamat: {alamat}\n"
        self.display_text.config(state='normal')
        self.display_text.delete(1.0, "end")
        self.display_text.insert("end", info_to_display)
        self.display_text.config(state='disabled')

    def konfirmasi_pembayaran(self):
        nama = self.txtnama.get()
        telepon = self.txtnotelepon.get()
        alamat = self.txtalamat.get()

        if not nama or not telepon or not alamat:
            messagebox.showinfo("Peringatan", "Isi kolom nama, nomor telepon, dan alamat terlebih dahulu.")
            return

        pesanan = "\n".join([f"{order[0]}: {order[1]} x Rp{order[2]}" for order in self.selected_orders])
        total_harga = sum(float(order[2]) for order in self.selected_orders)

        ongkir = 15.000 
        total_harga += ongkir

        riwayat = riwayat_pesanan()
        riwayat.nama = nama
        riwayat.telepon = telepon
        riwayat.alamat = alamat
        riwayat.pesanan = pesanan
        riwayat.total_harga = total_harga
        riwayat.ongkir = ongkir
        riwayat.simpan()

        messagebox.showinfo("Info", "Pembayaran berhasil")

        self.parent.destroy()
        self.previous_window.deiconify()

    def kembali_ke_sebelumnya(self):
        self.parent.destroy() 
        self.previous_window.deiconify() 
        
if __name__ == '__main__':
    root = tk.Tk()
    aplikasi = PesanMakanan(root, "Pesan Makanan")
    root.mainloop()