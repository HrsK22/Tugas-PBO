-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: sql.freedb.tech
-- Generation Time: Feb 16, 2024 at 12:11 PM
-- Server version: 8.0.36-0ubuntu0.22.04.1
-- PHP Version: 8.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `freedb_bebek_carok`
--

-- --------------------------------------------------------

--
-- Table structure for table `menu_makanan`
--

CREATE TABLE `menu_makanan` (
  `makanan_id` int NOT NULL,
  `kode_makanan` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `makanan` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `harga_makanan` decimal(10,3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu_makanan`
--

INSERT INTO `menu_makanan` (`makanan_id`, `kode_makanan`, `makanan`, `harga_makanan`) VALUES
(1, 'Jumbo1', 'Bebek Madura Jumbo Bumbu Hitam', 42.000),
(2, 'Jumbo2', 'Bebek Madura Jumbo Laos', 42.000),
(3, 'Jumbo3', 'Bebek Madura Jumbo Lucknut', 50.000),
(4, 'Jumbo4', 'Bebek Madura Jumbo Ancor', 45.000),
(5, 'Sedang5', 'Bebek Madura Sedang Bumbu Hitam', 29.000),
(6, 'Sedang1', 'Bebek Madura Sedang Laos', 29.000),
(7, 'Sedang2', 'Bebek Madura Sedang Lucknut', 39.000),
(8, 'Sedang3', 'Bebek Madura Ancor', 33.000);

-- --------------------------------------------------------

--
-- Table structure for table `menu_minuman`
--

CREATE TABLE `menu_minuman` (
  `id_minuman` int NOT NULL,
  `kode_minuman` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `minuman` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `harga_minuman` decimal(10,3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu_minuman`
--

INSERT INTO `menu_minuman` (`id_minuman`, `kode_minuman`, `minuman`, `harga_minuman`) VALUES
(1, 'minum1', 'Teh Pucuk', 10.000),
(2, 'minum2', 'Air Mineral', 10.000),
(3, 'minum3', 'Es Teh', 8.000),
(4, 'minum4', 'Es Jeruk', 15.000),
(5, 'minum5', 'Es Milo', 15.000);

-- --------------------------------------------------------

--
-- Table structure for table `riwayat_pesanan`
--

CREATE TABLE `riwayat_pesanan` (
  `id_riwayat_pesanan` int NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `telepon` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `alamat` text COLLATE utf8mb4_general_ci NOT NULL,
  `pesanan` text COLLATE utf8mb4_general_ci NOT NULL,
  `ongkir` decimal(10,3) NOT NULL,
  `total_harga` decimal(10,3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `riwayat_pesanan`
--

INSERT INTO `riwayat_pesanan` (`id_riwayat_pesanan`, `nama`, `telepon`, `alamat`, `pesanan`, `ongkir`, `total_harga`) VALUES
(1, 'Haris Kurniawan', '081308130813', 'Gang xxxx xxxxx Desa xxxxxxxxx RTxxx RWxxx Blok xxxxxx No.xx Kec.xxxxxx xxxx Kab.Majalengka', 'Bebek Madura Jumbo Bumbu Hitam: 2 x Rp84.000\nTeh Pucuk: 2 x Rp20.000\nAir Mineral: 2 x Rp20.000', 15.000, 139.000);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `nama` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `level` enum('admin','customer') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'customer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `nama`, `password`, `level`) VALUES
(1, 'customer@gmail.com', 'customer', '$2y$10$KTcU94npcJdwlgu9iSF5dudm/p0QOpdj6QeeupzP5MegiEiKOA9I2', 'customer'),
(2, 'admin@gmail.com', 'admin', '$2y$10$l2zEnAAYtE962fjU2.aH9OLCklPNEwqOe/Fk5g6UvzU2A1WtqYGfa', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `menu_makanan`
--
ALTER TABLE `menu_makanan`
  ADD PRIMARY KEY (`makanan_id`);

--
-- Indexes for table `menu_minuman`
--
ALTER TABLE `menu_minuman`
  ADD PRIMARY KEY (`id_minuman`);

--
-- Indexes for table `riwayat_pesanan`
--
ALTER TABLE `riwayat_pesanan`
  ADD PRIMARY KEY (`id_riwayat_pesanan`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menu_makanan`
--
ALTER TABLE `menu_makanan`
  MODIFY `makanan_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `menu_minuman`
--
ALTER TABLE `menu_minuman`
  MODIFY `id_minuman` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `riwayat_pesanan`
--
ALTER TABLE `riwayat_pesanan`
  MODIFY `id_riwayat_pesanan` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
