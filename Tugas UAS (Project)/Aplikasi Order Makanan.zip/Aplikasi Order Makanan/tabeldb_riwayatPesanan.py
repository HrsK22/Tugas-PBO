from db import DBConnection as mydb

class riwayat_pesanan:
    def __init__(self):
        self.__id_riwayat_pesanan=None
        self.__nama=None
        self.__telepon=None
        self.__alamat=None
        self.__pesanan=None
        self.__ongkir=None
        self.__total_harga=None
        self.conn=None
        self.affected=None
        self.result=None

    @property
    def id_riwayat_pesanan(self): 
        return self.__id_riwayat_pesanan
    
    @property
    def nama(self):
        return self.__nama
    @nama.setter
    def nama(self, value):
        self.__nama = value

    @property
    def telepon(self):
        return self.__telepon
    @telepon.setter
    def telepon(self, value):
        self.__telepon = value
    
    @property
    def alamat(self):
        return self.__alamat
    @alamat.setter
    def alamat(self, value):
        self.__alamat = value
    
    @property
    def pesanan(self):
        return self.__pesanan
    @pesanan.setter
    def pesanan(self, value):
        self.__pesanan = value
    
    @property
    def ongkir(self):
        return self.__ongkir
    @ongkir.setter
    def ongkir(self, value):
        self.__ongkir = value

    @property
    def total_harga(self):
        return self.__total_harga
    @total_harga.setter
    def total_harga(self, value):
        self.__total_harga = value

    def simpan(self):
        self.conn = mydb()
        val = (self.__nama, self.__telepon, self.__alamat, self.__pesanan, self.__ongkir, self.__total_harga)
        sql = "INSERT INTO riwayat_pesanan (nama, telepon, alamat, pesanan, ongkir, total_harga) VALUES" + str(val)
        self.affected = self.conn.insert(sql)
        self.conn.disconnect
        return self.affected
    
    def update(self, id_riwayat_pesanan):
        self.conn = mydb()
        val = (self.nama, self.__telepon, self.__alamat, self.__pesanan, self.__ongkir, self.__total_harga, id_riwayat_pesanan)
        sql="UPDATE riwayat_pesanan SET nama = %s, telepon = %s, alamat = %s, pesanan = %s, ongkir = %s, total_harga = %s WHERE id_riwayat_pesanan=%s"
        self.affected = self.conn.update(sql, val)
        self.conn.disconnect
        return self.affected
    
    def updateBynama(self, nama):
        self.conn = mydb()
        val = (self.__telepon, self.__alamatself.__alamat, self.__ongkir, self.__pesanan, self.__total_harga, nama)
        sql = "UPDATE riwayat_pesanan SET telepon = %s, alamat = %s, pesanan = %s, ongkir = %s, total_harga = %s WHERE nama= %s"
        self.affected = self.conn.update(sql,val)
        self.caonn.disconnect
        return self.affected

    def delete(self, id_riwayat_pesanan):
        self.conn = mydb()
        sql = "DELETE FROM riwayat_pesanan WHERE id_riwayat_pesanan='" + str(id_riwayat_pesanan) +"'"
        self.affected = self.conn.delete(sql)
        self.conn.disconnect
        return self.affected

    def deleteBynama(self, nama):
        self.conn = mydb()
        sql = "DELETE FROM riwayat_pesanan WHERE nama='" + str(nama) +"'"
        self.affected = self.conn.delete(sql)
        self.conn.disconnect
        return self.affected
    
    def getByid_riwayat_pesanan(self, id_riwayat_pesanan):
        self.conn = mydb()
        sql = "SELCT * FROM riwayat_pesanan WHERE id_riwayat_pesanan='" + str(id_riwayat_pesanan) + "'"
        self.result = self.conn.findOne(sql)
        self.__nama = self.result[1]
        self.__telepon = self.result[2]
        self.__alamat = self.result[3]
        self.__pesanan = self.result[4]
        self.__ongkir = self.result[5]
        self.__total_harga = self.result[6]
        self.conn.disconnect
        return self.result
    
    def getBynama(self, nama):
        a = str(nama)
        b = a.strip()
        self.conn = mydb()
        sql = "SELECT *FROM riwayat_pesanan WHERE nama='" + b + "'"
        self.result = self.conn.findOne(sql)
        if(self.result!=None):
            self.__nama = self.result[1]
            self.__telepon = self.result[2]
            self.__alamat = self.result[3]
            self.__pesanan = self.result[4]
            self.__ongkir = self.result[5]
            self.__total_harga = self.result[6]
            self.affected = self.conn.cursor.rowcount
        else:
            self.__nama = ''    
            self.__telepon = ''
            self.__alamat = ''
            self.__pesanan = ''
            self.__ongkir = ''
            self.__total_harga = ''
            self.affected = 0
        self.conn.disconnect
        return self.result
    
    def getAllData(self):
        self.conn = mydb()
        sql = "SELECT * FROM riwayat_pesanan"
        self.result = self.conn.findAll(sql)
        self.conn.disconnect()
        return self.result