import tkinter as tk
from tkinter import Frame, Label, Button, BOTH, END, Scrollbar
from PIL import Image, ImageTk
from tabeldb_riwayatPesanan import riwayat_pesanan

class RiwayatPemesanan:
    def __init__(self, parent, update_main_window):
        self.parent = parent
        self.update_main_window = update_main_window
        self.parent.title("Riwayat Pemesanan")
        self.parent.resizable(False, False)
        self.center_window()
        self.aturKomponen()
        self.set_icon()
        
    def set_icon(self):
        icon_image = Image.open("icon.png")
        tk_icon = ImageTk.PhotoImage(icon_image)
        self.parent.iconphoto(False, tk_icon)

    def center_window(self):
        screen_width = self.parent.winfo_screenwidth()
        screen_height = self.parent.winfo_screenheight()

        x = (screen_width - 450) // 2
        y = (screen_height - 350) // 2

        self.parent.geometry("450x350+{}+{}".format(x, y))

    def aturKomponen(self):
        mainFrame = Frame(self.parent, bd=10, bg='red')
        mainFrame.pack(fill=BOTH, expand=True)

        Label(mainFrame, text='Riwayat Pemesanan', fg="white", bg="grey", width=15, height=2, bd=5,relief='solid',font=('Helvetica', 15, 'bold')).grid(row=0, column=0, columnspan=5 ,sticky='NSEW', padx=5, pady=5)

        Button(mainFrame, text='Kembali', width=15, height=2, command=self.btnKembaliDariRiwayat_click).grid(row=10, column=0)

        self.text_widget = tk.Text(mainFrame, wrap="word", height=10, width=50, state='disabled')
        self.text_widget.grid(row=1, column=0, columnspan=5, padx=5, pady=5)

        scrollbar = Scrollbar(mainFrame, command=self.text_widget.yview)
        scrollbar.grid(row=1, column=6, sticky='nsew')
        self.text_widget['yscrollcommand'] = scrollbar.set


        self.current_index = 0
        self.load_data()

        Button(mainFrame, text='Prev', command=self.show_prev, width=10, height=2).grid(row=2, column=1)
        Button(mainFrame, text='Next', command=self.show_next, width=10, height=2).grid(row=2, column=2)

    def load_data(self):
        database = riwayat_pesanan()
        data = database.getAllData()

        if data:
            self.text_widget.config(state='normal')
            self.text_widget.delete(1.0, END)
            self.text_widget.insert(END, f"ID: {data[self.current_index][0]}\n")
            self.text_widget.insert(END, f"Nama: {data[self.current_index][1]}\n")
            self.text_widget.insert(END, f"Telepon: {data[self.current_index][2]}\n")
            self.text_widget.insert(END, f"Alamat:\n{data[self.current_index][3]}\n")
            self.text_widget.insert(END, f"Pesanan:\n{data[self.current_index][4]}\n")
            self.text_widget.insert(END, f"Ongkir: {data[self.current_index][5]}\n")
            self.text_widget.insert(END, f"Total Harga: {data[self.current_index][6]}\n")
            self.text_widget.config(state='disabled')

    def show_next(self):
        database = riwayat_pesanan()
        data = database.getAllData()

        if self.current_index < len(data) - 1:
            self.current_index += 1
            self.load_data()

    def show_prev(self):
        if self.current_index > 0:
            self.current_index -= 1
            self.load_data()

    def btnKembaliDariRiwayat_click(self):
        self.parent.destroy()

if __name__ == '__main__':
    root = tk.Tk()
    aplikasi = RiwayatPemesanan(root, "Riwayat Pemesanan")
    root.mainloop()