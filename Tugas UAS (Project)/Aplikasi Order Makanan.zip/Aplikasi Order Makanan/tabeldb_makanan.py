from db import DBConnection as mydb

class menu_makanan:
    def __init__(self):
        self.__id_makanan=None
        self.__kode_makanan=None
        self.__makanan=None
        self.__harga_makanan=None
        self.conn=None
        self.affected=None
        self.result=None

    @property
    def id_makanan(self): 
        return self.__id_makanan
    
    @property
    def kode_makanan(self):
        return self.__kode_makanan
    @kode_makanan.setter
    def kode_makanan(self, value):
        self.__kode_makanan = value

    @property
    def makanan(self):
        return self.__makanan
    @makanan.setter
    def makanan(self, value):
        self.__makanan = value
    
    @property
    def harga_makanan(self):
        return self.__harga_makanan
    @harga_makanan.setter
    def harga_makanan(self, value):
        self.harga_makanan = value
    
    def simpan(self):
        self.conn = mydb()
        val = (self.__kode_makanan, self.__makanan, self.__harga_makanan)
        sql = "INSERT INTO menu_makanan (kode_makanan, makanan, harga_makanan) VALUES" + str(val)
        self.affected = self.conn.insert(sql)
        self.conn.disconnect
        return self.affected
    
    def update(self, id_makanan):
        self.conn = mydb()
        val = (self.kode_makanan, self.__makanan, self.__harga_makanan, id_makanan)
        sql="UPDATE menu_makanan SET kode_makanan = %s, makanan = %s,harga_makanan = %s WHERE id_makanan=%s"
        self.affected = self.conn.update(sql, val)
        self.conn.disconnect
        return self.affected
    
    def updateBykode_makanan(self, kode_makanan):
        self.conn = mydb()
        val = (self.__makanan, self.__harga_makanan, kode_makanan)
        sql = "UPDATE menu_makanan SET makanan = %s,harga_makanan = %s WHERE kode_makanan= %s"
        self.affected = self.conn.update(sql,val)
        self.caonn.disconnect
        return self.affected

    def delete(self, id_makanan):
        self.conn = mydb()
        sql = "DELETE FROM menu_makanan WHERE id_makanan='" + str(id_makanan) +"'"
        self.affected = self.conn.delete(sql)
        self.conn.disconnect
        return self.affected

    def deleteBykode_makanan(self, kode_makanan):
        self.conn = mydb()
        sql = "DELETE FROM menu_makanan WHERE kode_makanan='" + str(kode_makanan) +"'"
        self.affected = self.conn.delete(sql)
        self.conn.disconnect
        return self.affected
    
    def getByid_makanan(self, id_makanan):
        self.conn = mydb()
        sql = "SELCT * FROM menu_makanan WHERE id_makanan='" + str(id_makanan) + "'"
        self.result = self.conn.findOne(sql)
        self.__kode_makanan = self.result[1]
        self.__makanan = self.result[2]
        self.__harga_makanan = self.result[3]
        self.conn.disconnect
        return self.result
    
    def getBykode_makanan(self, kode_makanan):
        a = str(kode_makanan)
        b = a.strip()
        self.conn = mydb()
        sql = "SELECT *FROM menu_makanan WHERE kode_makanan='" + b + "'"
        self.result = self.conn.findOne(sql)
        if(self.result!=None):
            self.__kode_makanan = self.affected[1]
            self.__makanan = [2]
            self.__harga_makanan = [3]
            self.affected = self.conn.cursor.rowcount
        else:
            self.__kode_makanan = ''    
            self.__makanan = ''
            self.__harga_makanan = ''
            self.affected = 0
        self.conn.disconnect
        return self.result
    
    def getAllData(self):
        self.conn = mydb()
        sql = "SELECT * FROM menu_makanan"
        self.result = self.conn.findAll(sql)
        self.conn.disconnect()
        return self.result

"""
A = menu_makanan()
B = A.getAllData()
print(" Menampilkan Semua Data")
print(B)
"""