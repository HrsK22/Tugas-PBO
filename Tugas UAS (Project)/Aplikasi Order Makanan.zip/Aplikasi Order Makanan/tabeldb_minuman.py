from db import DBConnection as mydb

class menu_minuman:
    def __init__(self):
        self.__id_minuman=None
        self.__kode_minuman=None
        self.__minuman=None
        self.__harga_minuman=None
        self.conn=None
        self.affected=None
        self.result=None

    @property
    def id_minuman(self): 
        return self.__id_minuman
    
    @property
    def kode_minuman(self):
        return self.__kode_minuman
    @kode_minuman.setter
    def kode_minuman(self, value):
        self.__kode_minuman = value

    @property
    def minuman(self):
        return self.__minuman
    @minuman.setter
    def minuman(self, value):
        self.__minuman = value
    
    @property
    def harga_minuman(self):
        return self.__harga_minuman
    @harga_minuman.setter
    def harga_minuman(self, value):
        self.__harga_minuman = value
    
    def simpan(self):
        self.conn = mydb()
        val = (self.__kode_minuman, self.__minuman, self.__harga_minuman)
        sql = "INSERT INTO menu_minuman (kode_minuman, minuman, harga_minuman) VALUES" + str(val)
        self.affected = self.conn.insert(sql)
        self.conn.disconnect
        return self.affected
    
    def update(self, id_minuman):
        self.conn = mydb()
        val = (self.kode_minuman, self.__minuman, self.__harga_minuman, id_minuman)
        sql="UPDATE menu_minuman SET kode_minuman = %s, minuman = %s,harga_minuman = %s WHERE id_minuman=%s"
        self.affected = self.conn.update(sql, val)
        self.conn.disconnect
        return self.affected
    
    def updateBykode_minuman(self, kode_minuman):
        self.conn = mydb()
        val = (self.__minuman, self.__harga_minuman, kode_minuman)
        sql = "UPDATE menu_minuman SET minuman = %s,harga_minuman = %s WHERE kode_minuman= %s"
        self.affected = self.conn.update(sql,val)
        self.conn.disconnect
        return self.affected

    def delete(self, id_minuman):
        self.conn = mydb()
        sql = "DELETE FROM menu_minuman WHERE id_minuman='" + str(id_minuman) +"'"
        self.affected = self.conn.delete(sql)
        self.conn.disconnect
        return self.affected

    def deleteBykode_minuman(self, kode_minuman):
        self.conn = mydb()
        sql = "DELETE FROM menu_minuman WHERE kode_minuman='" + str(kode_minuman) +"'"
        self.affected = self.conn.delete(sql)
        self.conn.disconnect
        return self.affected
    
    def getByid_minuman(self, id_minuman):
        self.conn = mydb()
        sql = "SELCT * FROM menu_minuman WHERE id_minuman='" + str(id_minuman) + "'"
        self.result = self.conn.findOne(sql)
        self.__kode_minuman = self.result[1]
        self.__minuman = self.result[2]
        self.__harga_minuman = self.result[3]
        self.conn.disconnect
        return self.result
    
    def getBykode_minuman(self, kode_minuman):
        a = str(kode_minuman)
        b = a.strip()
        self.conn = mydb()
        sql = "SELECT *FROM menu_minuman WHERE kode_minuman='" + b + "'"
        self.result = self.conn.findOne(sql)
        if(self.result!=None):
            self.__kode_minuman = self.affected[1]
            self.__minuman = self.affected[2]
            self.__harga_minuman = self.affected[3]
            self.affected = self.conn.cursor.rowcount
        else:
            self.__kode_minuman = ''    
            self.__minuman = ''
            self.__harga_minuman = ''
            self.affected = 0
        self.conn.disconnect
        return self.result
    
    def getAllData(self):
        self.conn = mydb()
        sql = "SELECT * FROM menu_minuman"
        self.result = self.conn.findAll(sql)
        self.conn.disconnect()
        return self.result

"""
A = menu_minuman()
B = A.getAllData()
print(" Menampilkan Semua Data")
print(B)
"""
